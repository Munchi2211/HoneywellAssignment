package com.honeywell.demo.employeeDemo.rest.service.impl;


import com.honeywell.demo.employeeDemo.dao.entity.Employee;
import com.honeywell.demo.employeeDemo.dao.repository.EmployeeRepository;
import com.honeywell.demo.employeeDemo.rest.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.TransientDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Override
    @Transactional
    public Employee saveEmployee(Employee employee) {
        Employee savedEmployee = null;
        try {
              savedEmployee = employeeRepository.save(employee);
        } catch (TransientDataAccessException transientException) {
            System.out.println("TransientDataAccessException while inserting record {}"+transientException.getCause());
        } catch (DataAccessException dataAccessException) {
            System.out.println("DataAccessException while inserting record {}"+dataAccessException.getCause());
        } catch (Exception ex) {
            System.out.println("Exception while inserting record {}"+ex.getCause());
        }
        return savedEmployee;
    }

    @Override
    public Employee getEmployeesBasedOnParams(String gender, String age) {
        Employee employee = null;
        try{
            employee = employeeRepository.getEmployees(gender,age);
        } catch (TransientDataAccessException transientException) {
            System.out.println("TransientDataAccessException while fetching record {}"+transientException.getCause());
        } catch (DataAccessException dataAccessException) {
            System.out.println("DataAccessException while fetching record {}"+dataAccessException.getCause());
        } catch (Exception ex) {
            System.out.println("Exception while fetching record {}"+ex.getCause());
        }

        return employee;
    }
}
