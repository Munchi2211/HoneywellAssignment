package com.honeywell.demo.employeeDemo.rest.service;

import com.honeywell.demo.employeeDemo.dao.entity.Credentials;
import com.honeywell.demo.employeeDemo.models.request.CredentialsDTO;


public interface CredentialsService {

    Credentials getCredentials(CredentialsDTO credentialsDTO) throws Exception;
}
