package com.honeywell.demo.employeeDemo.rest.service;

import com.honeywell.demo.employeeDemo.dao.entity.Employee;

public interface EmployeeService {

    Employee saveEmployee(Employee employee);

    Employee getEmployeesBasedOnParams(String gender, String age);
}
