package com.honeywell.demo.employeeDemo.exception;

public class BadRequestException extends RuntimeException{

    public BadRequestException() {
    }

    public BadRequestException (String errorCode, String errorMessage){

    }
}
