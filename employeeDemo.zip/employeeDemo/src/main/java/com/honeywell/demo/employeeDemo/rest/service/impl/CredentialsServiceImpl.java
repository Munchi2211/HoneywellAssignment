package com.honeywell.demo.employeeDemo.rest.service.impl;

import com.honeywell.demo.employeeDemo.dao.entity.Credentials;
import com.honeywell.demo.employeeDemo.dao.repository.CredentialsRepository;
import com.honeywell.demo.employeeDemo.exception.RecordNotFoundException;
import com.honeywell.demo.employeeDemo.models.request.CredentialsDTO;
import com.honeywell.demo.employeeDemo.rest.service.CredentialsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.TransientDataAccessException;
import org.springframework.stereotype.Service;

@Service
public class CredentialsServiceImpl implements CredentialsService {

    @Autowired
    private CredentialsRepository credentialsRepository;

    @Override
    public Credentials getCredentials(CredentialsDTO credentialsDTO) throws Exception {
        Credentials credentials = null;
        try {
            if (credentialsDTO != null) {
                credentials = credentialsRepository.getCredentials(credentialsDTO.getUsername(), credentialsDTO.getPassword());
                System.out.println("credentials: "+credentials.getUsername());
                if (credentials == null) {
                    throw new RecordNotFoundException();
                }
            }
        } catch (TransientDataAccessException transientException) {
            System.out.println("TransientDataAccessException while fetching record {}"+transientException.getCause());
        } catch (DataAccessException dataAccessException) {
            System.out.println("DataAccessException while fetching record {}"+dataAccessException.getCause());
        } catch (Exception ex) {
            System.out.println("Exception while fetching record {}"+ex.getCause());
        }
        return credentials;
    }
}
