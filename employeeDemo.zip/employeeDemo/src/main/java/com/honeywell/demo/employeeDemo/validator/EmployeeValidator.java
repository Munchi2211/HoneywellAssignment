package com.honeywell.demo.employeeDemo.validator;

import com.honeywell.demo.employeeDemo.exception.BadRequestException;
import com.honeywell.demo.employeeDemo.models.request.CredentialsDTO;
import com.honeywell.demo.employeeDemo.models.request.EmployeeDTO;
import org.springframework.stereotype.Component;

@Component
public class EmployeeValidator {

    public void validateCredentials(CredentialsDTO credentialsDTO) {

        if(credentialsDTO != null){
            if(credentialsDTO.getUsername() == null || credentialsDTO.getPassword() == null){
                throw new BadRequestException("403","input data is not valid");
            }
        }

    }

    public void validateEmployee(EmployeeDTO employeeDTO) {
        if(employeeDTO != null){
            if(employeeDTO.getId() == null || employeeDTO.getName() == null || employeeDTO.getAge() == null || employeeDTO.getGender() == null){
                throw new BadRequestException("400","input data is not valid");
            }
        }

    }

    public void validateEmployeeBasedOnValues(String gender, String age) {
        if(age == null || gender == null ){
            throw new BadRequestException("400","input data is not valid");
        }
    }
}
