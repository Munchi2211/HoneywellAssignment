package com.honeywell.demo.employeeDemo.exception;

public class RecordNotFoundException extends RuntimeException{

    public RecordNotFoundException() {
    }

    public RecordNotFoundException(String errorCode, String errorMessage) {
    }


}
