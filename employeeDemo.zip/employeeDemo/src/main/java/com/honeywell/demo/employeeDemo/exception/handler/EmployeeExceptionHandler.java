package com.honeywell.demo.employeeDemo.exception.handler;

import com.honeywell.demo.employeeDemo.exception.BadRequestException;
import com.honeywell.demo.employeeDemo.exception.Error;
import com.honeywell.demo.employeeDemo.exception.RecordNotFoundException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class EmployeeExceptionHandler extends ResponseEntityExceptionHandler {


    @ExceptionHandler(Exception.class)
    public final ResponseEntity<Object> handleGenericException(Exception ex, WebRequest request) {
        return new ResponseEntity(ex, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(BadRequestException.class)
    public final ResponseEntity<Object> handleBadRequest(BadRequestException ex, WebRequest request) {
        Error error = new Error();
        error.setErrorCode("400");
        error.setErrorMessage("input data is not valid");
        return new ResponseEntity(error,HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(RecordNotFoundException.class)
    public final ResponseEntity<Object> handleRecordNotFound(RecordNotFoundException ex, WebRequest request) {
        Error error = new Error();
        error.setErrorCode("404");
        error.setErrorMessage("record not found");
        return new ResponseEntity(error, HttpStatus.NOT_FOUND);
    }


    @ExceptionHandler({ NullPointerException.class, IllegalArgumentException.class, IllegalStateException.class })
    public ResponseEntity<Object> handleInternal( RuntimeException ex, final WebRequest request) {
        return new ResponseEntity(ex, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @Override
    protected ResponseEntity<Object> handleHttpMessageNotReadable(final HttpMessageNotReadableException ex, final HttpHeaders headers, final HttpStatus status, final WebRequest request) {
        Error error = new Error();
        error.setErrorCode("400");
        error.setErrorMessage("Bad request");
        return new ResponseEntity(error, HttpStatus.BAD_REQUEST);
    }
}
