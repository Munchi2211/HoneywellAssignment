package com.honeywell.demo.employeeDemo.rest.resource;

import com.honeywell.demo.employeeDemo.dao.entity.Credentials;
import com.honeywell.demo.employeeDemo.dao.entity.Employee;
import com.honeywell.demo.employeeDemo.exception.BadRequestException;
import com.honeywell.demo.employeeDemo.models.request.CredentialsDTO;
import com.honeywell.demo.employeeDemo.models.request.EmployeeDTO;
import com.honeywell.demo.employeeDemo.rest.service.CredentialsService;
import com.honeywell.demo.employeeDemo.rest.service.EmployeeService;
import com.honeywell.demo.employeeDemo.validator.EmployeeValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@RestController
@RequestMapping("/v1")
public class EmployeeResource {

    @Autowired
    private EmployeeValidator employeeValidator;

    @Autowired
    private CredentialsService credentialsService;

    @Autowired
    private EmployeeService employeeService;

    @PostMapping("/login")
    public ResponseEntity validateEmployee(@RequestBody CredentialsDTO credentialsDTO, HttpServletRequest request, HttpServletResponse response) throws Exception {

        employeeValidator.validateCredentials(credentialsDTO);
        System.out.println("credentialsDTO: "+credentialsDTO);
        Credentials credentials = credentialsService.getCredentials(credentialsDTO);
        System.out.println("credentialsDTO name: "+credentials.getUsername());
        Cookie loginCookie=new Cookie("name",credentials.getUsername());
        loginCookie.setMaxAge(30*5);
        response.addCookie(loginCookie);
        ResponseEntity responseEntity =	new ResponseEntity(HttpStatus.OK);
      return responseEntity;
  }

    @PostMapping("/employee")
    public ResponseEntity createEmployee(@RequestBody EmployeeDTO employeeDTO,HttpServletRequest request, HttpServletResponse response){
        Employee employee1 = null;
        System.out.println("employ dto: "+employeeDTO);
        employeeValidator.validateEmployee(employeeDTO);

/*        Employee employee = new Employee();
        if (employeeDTO != null){
            employee.setId(employeeDTO.getId());
            employee.setName(employeeDTO.getName());
            employee.setAge(employeeDTO.getAge());
            employee.setGender(employeeDTO.getGender());
        }
        employee1 = employeeService.saveEmployee(employee);*/

       Cookie[] cookies = request.getCookies();
        for(Cookie cookie: cookies){
            if(employeeDTO.getName().equalsIgnoreCase(cookie.getValue())){
                Employee employee = new Employee();
                if (employeeDTO != null){
                    employee.setId(employeeDTO.getId());
                    employee.setName(employeeDTO.getName());
                    employee.setAge(employeeDTO.getAge());
                    employee.setGender(employeeDTO.getGender());
                }
                 employee1 = employeeService.saveEmployee(employee);
            }else{
                throw new BadRequestException();
            }
        }
        ResponseEntity responseEntity =	new ResponseEntity(employee1,HttpStatus.OK);

        return responseEntity;
    }

    @GetMapping("/employees/{gender}/{age}")
    public ResponseEntity getEmployee(@PathVariable("gender") String gender,@PathVariable("age") String age,
                                         HttpServletRequest request, HttpServletResponse response){
        Employee employeesBasedOnParams = null;
        System.out.println("employ : "+gender+"age: "+age);
        employeeValidator.validateEmployeeBasedOnValues(gender,age);
        //employeesBasedOnParams = employeeService.getEmployeesBasedOnParams(gender, age);
        //we don't have user name, hence we can check based on user name. So i check null condition
        Cookie[] cookies = request.getCookies();
        for(Cookie cookie: cookies){
            if(cookie.getValue() != null){
                employeesBasedOnParams = employeeService.getEmployeesBasedOnParams(gender, age);
            }
        }
        ResponseEntity responseEntity =	new ResponseEntity(employeesBasedOnParams,HttpStatus.OK);

        return responseEntity;
    }

}
