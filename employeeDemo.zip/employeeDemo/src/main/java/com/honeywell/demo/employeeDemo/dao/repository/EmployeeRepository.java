package com.honeywell.demo.employeeDemo.dao.repository;

import com.honeywell.demo.employeeDemo.dao.entity.Credentials;
import com.honeywell.demo.employeeDemo.dao.entity.Employee;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface EmployeeRepository extends CrudRepository<Employee,String> {
    @Query(value = "SELECT * FROM employee t WHERE t.gender =:gender and t.age =:age",nativeQuery = true)
    Employee getEmployees(@Param("gender") String gender, @Param("age") String age);
}
